import Database from 'better-sqlite3';

const db = new Database('./Database/petStore.db');

export default db;
